const letters = /^[A-Za-z]+$/;
const numbers = /^[0-9]+$/;
const numbers_letters = /^[A-Za-z0-9]+$/;


function getAllElementsFromForm(form)
{
    var tab=[];
    for(var i=0 ; i<form.elements.length;i++ ){
        if(form.elements[i].nodeName =="INPUT"){
           if(form.elements[i].value=="" && form.elements[i].id !="class") return null;
        tab.push(form.elements[i].value);
        }
    }
    return tab;
}
