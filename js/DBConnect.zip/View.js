

function createUserView(){
    const query = `
          CREATE OR REPLACE VIEW "user_view" AS SELECT 
          id,imie,nazwisko,klasa
          FROM uzytkownik;
        ;
    `;
    client.query(query, (err, res)=>{
        if(err){
            console.log("userView " + err); return;
        }
    })
}


function createStudentAssessmentView(){
    const query = `
          CREATE OR REPLACE VIEW oceny_view AS SELECT
          oceny.id,oceny.stopien, uzytkownik.imie,uzytkownik.nazwisko, przedmiot.nazwa_przedmiotu
          FROM oceny
          INNER JOIN "uzytkownik"
          on oceny.uczen = uzytkownik.id
          INNER JOIN "przedmiot"
          on oceny.przedmiot = przedmiot.id;
        ;
    `;
    client.query(query, (err, res)=>{
        if(err){
            console.log("ocenyView " + err); return;
        }
    })
}

function createClassView(){
   const query = `
          CREATE OR REPLACE VIEW klasa_view AS SELECT
          uzytkownik.imie,uzytkownik.nazwisko,nazwaKlasy
          FROM klasa
          INNER JOIN "uzytkownik"
          on klasa.wychowawca = uzytkownik.id;
        ;
    `;
    client.query(query, (err, res)=>{
        if(err){
            console.log("klasa_view " + err); return;
        }
    })
}

function createScheduleView(){
    const query = `
          CREATE OR REPLACE VIEW planZajec_view AS SELECT
          planZajec.id,przedmiot.nazwa_przedmiotu, klasa.nazwaKlasy, sala.nazwa_sali
          FROM planZajec
          INNER JOIN "przedmiot"
          on planZajec.przedmiot = przedmiot.id
          INNER JOIN "klasa"
          on planZajec.klasa = klasa.id
          INNER JOIN "sala"
          on planZajec.zarezerwowana_sala = sala.id;
        ;
    `;
    client.query(query, (err, res)=>{
        if(err){
            console.log("godzinyLekcyjneView " + err); return;
        }
    })
}

function selectStudent(){
    const query = `
    godziny_lekcyjne_view where stopien >
    (
        Select stopien From godziny_lekcyjne_view WHERE id = 1
    )
`;
  return query;
}

function selectUsers(){
    const query = `
    user_view where imie in
    (
        Select imie From Uzytkownik WHERE uprawnienie = 1
    )
`;
  return query;
}

function selectScheduleView(){
    const query = `
    planZajec_view where nazwaKlasy in
    (
        Select nazwaKlasy From klasa WHERE id = 1
    )
`;
  return query;
}

function selectClassView(){
    const query = `
    klasa_view where imie in
    (
        Select imie From Uzytkownik WHERE id=1
    )
`;
  return query;
}

