const { Client } = require('pg');
const client = new Client({
    host: "127.0.0.1",
    port: 5432,
    database: "postgres",
    user: "obserwator",
    password: "obserwator"
    });
// password 1234 uczelnia
    function connect(){
        client.connect();
    }

    function disconnect(){
        client.end();
    }
    connect();

