function generatePermissions(){
    const query = `
    INSERT INTO uprawnienia (nazwaUprawnienia) VALUES
    ('uczen'),
    ('nauczyciel'),
    ('gosc'),
    ('admin');
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log(err);
        return;
    }
    })
}

function generateDegrees(){
    const query = `
    INSERT INTO stopnie (stopien) VALUES
    ('1'),
    ('2'),
    ('3'),
    ('4'),
    ('5'),
    ('6');
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log(err);
        return;
    }
    })
}

function generateLessonHours(){
    const query = `
    INSERT INTO godzinyLekcyjne (rozpoczecie,zakonczenie) VALUES
    ('8:00', '8:45'),
    ('9:00', '9:45'),
    ('10:00', '10:45'),
    ('11:00', '11:45'),
    ('12:00', '12:45'),
    ('13:00', '13:45');
    `;
    client.query(query, (err, res)=>{
    if(err){
        return;
    }
    })
}

function generateRoom(){
    const query = `
    INSERT INTO sala (nazwa_sali) VALUES
    ('b5'),
    ('a1'),
    ('a2'),
    ('b16'),
    ('b11');
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log(err); return;
    }
    })
}

function generateCalendar(){
    const query = `
    INSERT INTO kalendarz (dzien,miesiac,rok) VALUES
    ('1','11','2021'),
    ('2','11','2021'),
    ('3','11','2021'),
    ('4','11','2021'),
    ('5','11','2021'),
    ('6','11','2021'),
    ('7','11','2021'),
    ('8','11','2021');
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log(err); return;
    }
    })
}

function generateRoomReservation(){
    const query = `
    INSERT INTO rezerwacjaSali (dzienRezerwacji,godzina,sala) VALUES
    ('1','1','1'),
    ('2','2','1'),
    ('3','3','2'),
    ('4','4','1'),
    ('5','5','3'),
    ('6','6','1');
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log(err); return;
    }
    })
}

function generateUser(){
    const query = `
    INSERT INTO uzytkownik (imie,nazwisko,uprawnienie,login,haslo) VALUES
    ('Kamil','Frac','4','login','haslo'),
    ('Bartosz','Kowalski','2','login','haslo'),
    ('Dawid','Nowak','3','login','haslo'),
    ('Marian','Szary','2','login','haslo'),
    ('Janusz','Zielony','1','login','haslo'),
    ('Grazyna','Czarna','1','login','haslo');
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log(err); return;
    }
    })
}

function generateRemarks(){
    const query = `
    INSERT INTO uwagi (nauczyciel,uczen,uwaga) VALUES
    ('2','5','Spoznia sie'),
    ('4','6','Nie uczy sie'),
    ('2','6','Wagaruje'),
    ('4','5','Wyzywa kolegow');
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log(err); return;
    }
    })
}

function generateClass(){
    const query = `
    INSERT INTO klasa (wychowawca,nazwaKlasy) VALUES
    ('1','1a'),
    ('3','2a');
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log(err); return;
    }
    })
}

function generateSubject(){
    const query = `
    INSERT INTO przedmiot (prowadzacy,nazwa_przedmiotu) VALUES
    ('2','Przyroda'),
    ('2','Informatyka'),
    ('4','Fizyka');
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log(err); return;
    }
    })
}

function generateStudentAssessment(){
    const query = `
    INSERT INTO oceny (stopien,uczen,przedmiot) VALUES
    ('3','5','1'),
    ('4','5','1'),
    ('5','6','2'),
    ('2','6','3');
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log(err); return;
    }
    })
}

function generateSchedule(){
    const query = `
    INSERT INTO planZajec (przedmiot,klasa,zarezerwowana_sala) VALUES
    ('1','1','1'),
    ('2','2','2'),
    ('1','2','3');
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log(err); return;
    }
    })
}

function generateData(){
    generatePermissions();
    generateDegrees();
    generateLessonHours();
    generateRoom();
    generateCalendar();
    generateRoomReservation();
    generateUser();
    generateRemarks();
    generateClass();
    generateSubject();
    generateStudentAssessment();
    generateSchedule();
}