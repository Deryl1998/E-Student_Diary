
function createUser(){
    const query = `
            CREATE TABLE uzytkownik(
            id integer primary key generated always as identity,
            imie VARCHAR ( 50 ) NOT NULL,
            nazwisko VARCHAR ( 50 ) NOT NULL,
            uprawnienie int NOT NULL,
                 FOREIGN KEY (uprawnienie)
                      REFERENCES uprawnienia (id) ON DELETE CASCADE,
            login VARCHAR ( 50 ) NOT NULL,
            haslo VARCHAR ( 50 ) NOT NULL,
            klasa int  NULL,
                 FOREIGN KEY (klasa)
                      REFERENCES klasa (id) ON DELETE CASCADE
        );
    `;
    client.query(query, (err, res)=>{
        if(err){
            console.log("user " + err); return;
        }
    })
}

function createClass(){
    const query = `
            CREATE TABLE klasa(
            id integer primary key generated always as identity,
            wychowawca int NOT NULL,
            nazwaKlasy VARCHAR ( 50 ) NOT NULL
        );
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log("klasa " + err); return;
    }
    })
}

function addConstraintToClass(){
    const query = `
            ALTER TABLE klasa
            ADD CONSTRAINT fk_class_wychowca
                FOREIGN KEY (wychowawca)
                   REFERENCES uzytkownik (id) ON DELETE CASCADE;
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log("klasa " + err); return;
    }
    })
}

function createSchedule(){
    const query = `
            CREATE TABLE planZajec(
            id integer primary key generated always as identity,
            przedmiot int NOT NULL,
                 FOREIGN KEY (przedmiot)
                      REFERENCES przedmiot (id) ON DELETE CASCADE,
            klasa int NOT NULL,
                FOREIGN KEY (klasa)
                      REFERENCES klasa (id) ON DELETE CASCADE,
            zarezerwowana_sala int NOT NULL,
                   FOREIGN KEY (zarezerwowana_sala)
                      REFERENCES rezerwacjaSali (id) ON DELETE CASCADE
        );
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log("plan zajec " + err); return;
    }
    })
}


 function createSubject(){
    const query = `
            CREATE TABLE przedmiot(
            id integer primary key generated always as identity,
            prowadzacy int NOT NULL,
            FOREIGN KEY (prowadzacy)
                      REFERENCES uzytkownik (id) ON DELETE CASCADE,
            nazwa_przedmiotu VARCHAR ( 50 ) NOT NULL
        );
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log("przedmiot " + err); return;
    }
    })
}

 function createRemarks(){
    const query = `
            CREATE TABLE uwagi(
            id integer primary key generated always as identity,
            nauczyciel int NOT NULL,
                 FOREIGN KEY (nauczyciel)
                    REFERENCES uzytkownik (id) ON DELETE CASCADE,
            uczen int NOT NULL,
                   FOREIGN KEY (nauczyciel)
                      REFERENCES uzytkownik (id) ON DELETE CASCADE,
            uwaga VARCHAR ( 255 ) NOT NULL
        );
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log("uwagi " + err); return;
    }
    })
}


function createPermissions(){
    const query = `
            CREATE TABLE uprawnienia(
            id integer primary key generated always as identity,
            nazwaUprawnienia VARCHAR ( 50 ) NOT NULL
        );
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log("uprawnienia " + err); return;
    }
    })
}

function createStudentAssessment(){
    const query = `
            CREATE TABLE oceny(
            id integer primary key generated always as identity,
            stopien int NOT NULL,
                  FOREIGN KEY (stopien)
                         REFERENCES stopnie (id) ON DELETE CASCADE,
            uczen int NOT NULL,
                  FOREIGN KEY (uczen)
                      REFERENCES uzytkownik (id) ON DELETE CASCADE,
            przedmiot int NOT NULL,
                   FOREIGN KEY (przedmiot)
                         REFERENCES przedmiot (id) ON DELETE CASCADE
        );
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log("oceny " + err); return;
    }
    })
}

function createDegrees(){
    const query = `
            CREATE TABLE stopnie(
            id integer primary key generated always as identity,
            stopien int NOT NULL
        );
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log("stopnie " + err); return;
    }
    })
}

function createCalendar(){
    const query = `
            CREATE TABLE kalendarz(
            id integer primary key generated always as identity,
            dzien int NOT NULL,
            miesiac int NOT NULL,
            rok int NOT NULL
        );
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log("dzien " + err); return;
    }
    })
}

function createRoomReservation(){
    const query = `
            CREATE TABLE rezerwacjaSali(
            id integer primary key generated always as identity,
            dzienRezerwacji int NOT NULL,
                 FOREIGN KEY (dzienRezerwacji)
                    REFERENCES kalendarz (id) ON DELETE CASCADE,
            godzina int NOT NULL,
                 FOREIGN KEY (godzina)
                    REFERENCES godzinyLekcyjne (id) ON DELETE CASCADE ,
            sala int NOT NULL,
                 FOREIGN KEY (sala)
                    REFERENCES sala (id) ON DELETE CASCADE
        );
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log("rezerwacja sali " + err); return;
    }
    })
}

 function createRoom(){
    const query = `
            CREATE TABLE sala(
            id integer primary key generated always as identity,
            nazwa_sali VARCHAR ( 50 ) NOT NULL
        );
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log("sala " + err); return;
    }
    })
}

 function createLessonHours(){
    const query = `
            CREATE TABLE godzinyLekcyjne(
            id integer primary key generated always as identity,
            rozpoczecie VARCHAR ( 50 ) NOT NULL,
            zakonczenie VARCHAR ( 50 ) NOT NULL
        );
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log("godziny " + err); return;
    }
    })
}

async function isExists (tableName){
    const query ={
        text:`SELECT FROM information_schema.tables WHERE table_name= $1::text`,
        values: [tableName],
    }
    const result = await client.query(query);
return result.rowCount;
}


function createDatabaseUsers(){
     const query = `
            CREATE USER obserwator NOSUPERUSER NOCREATEDB NOCREATEROLE LOGIN PASSWORD 'obserwator';
            CREATE USER uzytkownik NOSUPERUSER NOCREATEROLE LOGIN PASSWORD 'uzytkownik';
    

            REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA public FROM obserwator;
            REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA public FROM uzytkownik;
            
            GRANT USAGE ON SCHEMA public  TO obserwator;
            GRANT USAGE ON SCHEMA public TO uzytkownik;
            GRANT SELECT,REFERENCES on all tables in schema public  TO obserwator;
            GRANT SELECT,REFERENCES,DELETE,INSERT,UPDATE on all tables in schema public TO uzytkownik;
      
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log("role " + err); return;
    }
    })


}




async function createTables(){
    //connect();
    if( await isExists("sala") == 0){ 
        createRoom();
    }
    if(await isExists("uprawnienia") == 0){
        createPermissions()
    } 
    if(await isExists("stopnie") == 0) {
        createDegrees();
    }
    if(await isExists("godzinylekcyjne") == 0) {
        createLessonHours();
    }
    if(await isExists("kalendarz") == 0) {
        createCalendar();
    }
    if(await isExists("rezerwacjasali") == 0){
        createRoomReservation();
    }
    if(await isExists("uzytkownik") == 0) {
        createClass();
        createUser();
        addConstraintToClass();
        createUserView();
        createClassView();
    }
    if(await isExists("uwagi") == 0) {
        createRemarks();
    }
    if(await isExists("przedmiot") == 0){
        createSubject();
    }
    if(await isExists("oceny") == 0) {
        createStudentAssessment();
        createStudentAssessmentView()
    }
    if(await isExists("planzajec") == 0) {
        createSchedule();
        generateData();
        createScheduleView();
        createDatabaseUsers();
    }
   // disconnect();
}


function dropTables(){
    const query = `
    DROP TABLE IF EXISTS
    uzytkownik,
    klasa,
    planZajec,
    przedmiot,
    uwagi,
    uprawnienia,
    oceny,
    stopnie,
    kalendarz,
    rezerwacjaSali,
    sala,
    godzinyLekcyjne CASCADE ;
    `;
    client.query(query, (err, res)=>{
    if(err){
        console.log(err); return;
    }
    console.log("baza usunieta");
    })
}


createTables();